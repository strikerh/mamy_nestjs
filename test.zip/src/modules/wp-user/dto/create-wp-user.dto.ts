export class CreateWpUserDto {}
